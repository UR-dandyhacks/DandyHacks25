# 💖 The DandyHacks 2024 website

This is the website for DandyHacks 2024, the 12th run of the University of
Rochester's premier hackathon. Go Yellowjackets! 🐝

## 🍽️ Tech stack

Our tech stack is optimized for the best speed:

- HTML
- TailwindCSS
- [Vanilla JS](http://vanilla-js.com/)
